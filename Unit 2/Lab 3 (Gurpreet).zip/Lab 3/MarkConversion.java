 import javax.swing.*;
/**
 * Date; Sept, 2017 
 * Author; Gurpreet Lubana
 * 
 */
public class MarkConversion {
    
    
    public static void main(String[] args) { 
        
        double percentage;
        percentage = Double.parseDouble(JOptionPane.showInputDialog(null," what mark wiil you put in?"));
        
        if(percentage >=80 && percentage <100)
        
        
            
    }
    
    
    
}
