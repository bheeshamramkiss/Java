import javax.swing.*;
/**
 * Date; Sept, 2017 
 * Author; Gurpreet Lubana
 */ 
public class Pizzaprogram {
    
    
    public static void main(String[] args) { 
        
        double price; // declaring variables for price.sodaprice,hst
        double sodaPrice = 0;
        double hst;
        int pizzaSlice; // declaring variables for pizzaSlice,sodaCan,bill,total,pizzaprice
        int sodaCan;
        double bill;
        double total;
        double pizzaPrice = 0;
        
        
        // Ask the user how many pizza slices do they want
        pizzaSlice = Integer.parseInt(JOptionPane.showInputDialog(null, "How many pizza slices do you wnat"));
       
        sodaCan = Integer.parseInt(JOptionPane.showInputDialog(null, 
                                                               " Do you want any pop? If yes please put in how many drinks you want!"));
        
        if (pizzaSlice < 3 ){ 
            pizzaPrice = 2.00 * pizzaSlice;
            
            
        }
        else if (pizzaSlice >3){// if user buys less then 3 slices then calculate $2.00
            pizzaPrice = 1.00 * pizzaSlice;
        }
     
        
        sodaPrice =  0.5 * sodaCan;
        
        bill = pizzaPrice + sodaPrice;
        hst = bill * 0.13;
        total = bill + hst;
        
        JOptionPane.showMessageDialog(null, "# of pizza of slices are" + " " 
                                          + pizzaSlice +"\n" + "# of pop can are" + " " + sodaCan + "\n" + "sub total"
                                          + ":" + " " + "\n" + "hst" + ":" + " " + "$" + hst + "\n" + "Total" + "$" + " " + "$" + total );
        
        
        
        
        
        
    }
    
    
    
}
