import javax.swing.*; // importing
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;  //import for the date and time
import java.util.Calendar;
import java.text.*;  // import that will allow me to format to two decimal places
/**
 * Date: Sept. 2017
 * Author: Bheesham Ramkissoon
 * Description: Creates a receipt for up to 4 items, with the subtotal and tax
 */
public class Receipt {
    
    public static void main(String[] args) { 
        DateFormat df = new SimpleDateFormat("MM/dd/yy HH:mm");  //setting format for the date to be displayed
        Date date = new Date();
        NumberFormat number = NumberFormat.getInstance ();  //
        number.setMaximumFractionDigits (2);
        
        //currency formatting
        NumberFormat money = NumberFormat.getCurrencyInstance ();
        
        //percent formatting
        NumberFormat percent = NumberFormat.getPercentInstance ();
        
        
        String item1, item2, item3, item4, storeName;  // variables for the names of the 4 items
        double price1, price2, price3, price4, subTotal, hst, finalTotal;  //variables for the 4 items' prices
        
        // input
        storeName = JOptionPane.showInputDialog (null, "Welcome to the receipt generator! \nPlease tell me the name of your store.");
        item1 = JOptionPane.showInputDialog (null, "Great!, Now, what is the first item \nyou have to checkout?");
        price1 = Double.parseDouble (JOptionPane.showInputDialog (null, "And the price?"));
        item2 = JOptionPane.showInputDialog (null, "Sensational!, Now, what is the second item \nyou have to checkout?");     // asking for store name,
        price2 = Double.parseDouble (JOptionPane.showInputDialog (null, "And the price for that?"));                          //item names, and prices
        item3 = JOptionPane.showInputDialog (null, "Proper!, Now, what is the third item \nyou have to checkout?");  
        price3 = Double.parseDouble (JOptionPane.showInputDialog (null, "And it's price?"));
        item4 = JOptionPane.showInputDialog (null, "Proper!, Now, what is the final item \nyou have to checkout?");
        price4 = Double.parseDouble (JOptionPane.showInputDialog (null, "And it's price?"));
        
        //processing
        subTotal = price1 + price2 + price3 + price4; //calculates subtotal of all items by adding their prices together
        hst = 0.13 * subTotal; // calculates the tax amount, assuming tax is 13%
        finalTotal = hst + subTotal; // adds tax and the subtotal together to give the final total
        
        //output
        JOptionPane.showMessageDialog (null, "    " + storeName + "\n" + df.format(date) + "\n" + item1 + "               " + money.format (price1) + "\n" + item2 + 
                                       "               " + money.format (price2)
                                           + "\n" + item3 + "              " + money.format (price3) + "\n" + item4 + "               " + money.format (price4) + "\n------------------------------------------" +
                                       "\nSubtotal" + "            " + money.format (subTotal) 
                                           + "\nHST" + "         " + money.format (hst) + "\n-----------------------------------------" +  "\nTotal" + 
                                       "                   " + money.format(finalTotal));
    }
    
    
}
