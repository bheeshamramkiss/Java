import javax.swing.*;
import java.text.*;
/**
 * Date: Sept. 2017
 * Author: Bheesham Ramkissoon
 * Description: A program that asks the user for dimensions, and proceeds to calculate the area and perimeter of a square, rectangle, and circle
 */
public class PI {
    
    
    public static void main(String[] args) { 
        Double xside, yside1, yside2, radius;    // xside is a variable for the side dimensions of the square, and yside are the variables for the rectangle
        Double areaSquare, perimeterSquare, areaRectangle, perimeterRectangle, areaCircle, perimeterCircle;   // declaring variable for the perimeter and the area of the shapes  
        Double PI = 3.14;
        
        // number formatting
        NumberFormat number = NumberFormat.getInstance ();
        number.setMaximumFractionDigits (2);
        
        // Start
        JOptionPane.showMessageDialog (null, " Welcome to the area and perimeter calculator!");
        
        // Area and circumference
        // Input
        radius = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the radius of the circle"));
        
        // Processing
        areaCircle = PI * radius * radius;
        perimeterCircle = 2 * PI * radius;
        
        // Output
        JOptionPane.showMessageDialog (null, "The formula for calculating the area of a circle is: PI * radius�." + "\nThe area of your circle is " + number.format(areaCircle) + "cm�");
        JOptionPane.showMessageDialog (null, "The formula for calculating the circumference of a circle is: 2 * PI * radius." + "\nThe circumference of your circle is " + number.format(perimeterCircle) + "cm");    
        
// area and perimeter of square
        // Input
        xside = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the length of the side of the square"));
        
        // Processing
        areaSquare = xside * xside;
        perimeterSquare = xside * 4;
        
        // Output
        JOptionPane.showMessageDialog (null, "The formula for calculating the area of a square is: (length of a side)�." + "\nThe area of your square is " + number.format(areaSquare) + "cm�");
        JOptionPane.showMessageDialog (null, "The formula for calculating the perimeter of a square is: (length of a side) * 4." + "\nThe perimeter of your square is " + number.format(perimeterSquare) + "cm");
        
        // area and perimeter of rectangle    
        // Input
        yside1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the length of the first side of the rectangle"));
        yside2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the length of the second side of the rectangle"));
        
        // Processing
        areaRectangle = yside1 * yside2;
        perimeterRectangle = yside1 + yside1 + yside2 + yside2;
        
        // Output
        JOptionPane.showMessageDialog (null, "The formula for calculating the area of a rectangles is: (length of side 1) * (length of side 2)." + "\nThe area of your rectangle is " + number.format(areaRectangle) + "cm�");
        JOptionPane.showMessageDialog (null, "The formula for calculating the perimeter of a rectangle is: 2 * (length of side 1) + 2 * (length of side 2)." + "\nThe perimeter of your rectangle is " + number.format(perimeterRectangle) + "cm");
        
        
        
    }
    
    
    
}
