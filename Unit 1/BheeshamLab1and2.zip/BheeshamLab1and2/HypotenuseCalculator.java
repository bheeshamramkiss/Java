import javax.swing.* ; // importing
import java.text.*;  // importing to allow me to format numbers to 2 decimals
import static java.lang.Math.sqrt;  // import to allow swuare root function
/**
 * Date: Sept. 2017
 * Author: Bheesham Ramkissoon
 * Description: Calculates the hypotenuse of a triangle when a use gives the lengths of the other two sides
 */
public class HypotenuseCalculator {
    
    
    public static void main(String[] args) { 
        Double sideLength1, sideLength2, hypotenuse;  // variables for the sidelengths of the triangle, as well as the hypotenuse
        int choice; //variable for choice
        
        NumberFormat number = NumberFormat.getInstance ();  // formatting numbers to two decimal places
        number.setMaximumFractionDigits (2);
        
        //prompt for choice of user
        choice = Integer.parseInt (JOptionPane.showInputDialog (null, "Hello! For a centimeter calculation, type 1.\nIf you would like meters, type 2."));
        
        if (choice == 1){
            // input
            sideLength1 = Double.parseDouble(JOptionPane.showInputDialog (null, "Welcome to the hypotenuse calculator!\nPlease enter your first side length."));
            sideLength2 = Double.parseDouble(JOptionPane.showInputDialog (null, "What is the second side length?"));
        
           //processing
            hypotenuse = sqrt ((sideLength1*sideLength1) + (sideLength2*sideLength2));
        
           //output
           JOptionPane.showMessageDialog (null, "c� = a� + b� \nYour hypotenuse is " + number.format(hypotenuse) + "cm.");
        }
        if (choice == 2){
            // input
            sideLength1 = Double.parseDouble(JOptionPane.showInputDialog (null, "Welcome to the hypotenuse calculator!\nPlease enter your first side length."));
            sideLength2 = Double.parseDouble(JOptionPane.showInputDialog (null, "What is the second side length?"));
        
            //processing
            hypotenuse = sqrt ((sideLength1*sideLength1) + (sideLength2*sideLength2));
        
            //output
            JOptionPane.showMessageDialog (null, "c� = a� + b� \nYour hypotenuse is " + number.format(hypotenuse) + "m.");
        }
    }
    
    
}
