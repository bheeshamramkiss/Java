import javax.swing.* ; // import for dialog box library
import java.text.*;  // importing to allow me to format numbers to 2 decimals
/**
 * Date: Sept. 2017
 * Author: Bheesham Ramkissoon
 * Description: Will take two numbers and show their sum, difference, quotient, and product.
 */
public class AddSubtractMultiplyDivide {
    
    
    public static void main(String[] args) { 
        Double number1, number2, sum, quotient, product, difference;  // variables for two numbers, sum, quotient, prodcut, and differenece.
        int choice;  //variable for choice
        
        NumberFormat number = NumberFormat.getInstance ();  // formatting numbers to two decimal places
        number.setMaximumFractionDigits (2);
        
        //input
        number1 = Double.parseDouble (JOptionPane.showInputDialog (null, "Welcome! Please tell me your first number."));  //prompts the user for the first number
        number2 = Double.parseDouble (JOptionPane.showInputDialog (null, "Thank You! Now please tell me your second number."));  // prompts user for second number        
        
        //prompt for mode selection
        choice = Integer.parseInt (JOptionPane.showInputDialog (null, "HEY! YOU! YEAH you, the person! If you wanna:\nAdd, press 1\nSubtract, press 2\nMultiply, press 3\nDivide, press 4\n All at once, press 5"));
        
        if (choice == 1){
            
            //processing
            sum = number1 + number2;
            
            //output
            JOptionPane.showMessageDialog (null, "Okay,\nafter some hard work,\n I found the following of your numbers:\nSum: " + number.format(sum));
        }
        if (choice == 2){
            
            //processing
            difference = number1 - number2;
            
            //output
            JOptionPane.showMessageDialog (null, "Okay,\nafter some hard work,\n I found the following of your numbers:\nDifference: " + number.format(difference));
        }
        
        if (choice == 3){
            
            //processing
            product = number1 * number2;
            
            //output
            JOptionPane.showMessageDialog (null, "Okay,\nafter some hard work,\n I found the following of your numbers:\nProduct: " + number.format(product));
        }
        if (choice == 4){
            
            if (number2 == 0){
                JOptionPane.showMessageDialog (null, "YOU FOOL! DON'T YOU KNOW THAT YOU CAN'T DIVIDE BY 0?! GO LEARN MATH AND COME BACK");
            }
            else {
                //processing
                quotient = number1 / number2;
                
                //output
                JOptionPane.showMessageDialog (null, "Okay,\nafter some hard work,\n I found the following of your numbers:\nQuotient: " + number.format(quotient));
            }
        }
        
        if (choice==5){            
            
            //processing
            sum = number1 + number2;
            difference = number1 - number2;
            product = number1 * number2;
            quotient = number1 / number2;
            
            //output
            JOptionPane.showMessageDialog (null, "Okay,\nafter some hard work,\n I found the following of your numbers:\nSum: " + number.format(sum) + "\nDifference: "
                                               + number.format(difference) + "\nProduct: " + number.format(product) + "\nQuotient: " + number.format(quotient));
        }
        
        
        
    }
    
    
}
